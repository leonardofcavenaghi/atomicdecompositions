"""One launcher, independent flag and toric workspaces."""
__version__ = '1.1.0.dev1'

